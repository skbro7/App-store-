import { useState } from "react";
import Header from "@/components/header";
import MeetingForm from "@/components/meeting-form";
import TimezoneComparison from "@/components/timezone-comparison";
import RecentMeetings from "@/components/recent-meetings";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

export default function Dashboard() {
  const [selectedTimeZones, setSelectedTimeZones] = useState([
    "America/Los_Angeles",
    "America/New_York", 
    "Europe/London",
    "Asia/Tokyo"
  ]);

  const [referenceTime, setReferenceTime] = useState({
    date: new Date().toISOString().split('T')[0],
    time: "14:00",
    timezone: "America/Los_Angeles"
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Meeting Scheduler</h1>
              <p className="mt-1 text-sm text-slate-500">Schedule meetings across different time zones with ease</p>
            </div>
            <div className="mt-4 sm:mt-0">
              <Button className="inline-flex items-center px-4 py-2 bg-blue-500 text-white text-sm font-medium rounded-lg hover:bg-blue-600 transition-colors shadow-sm">
                <Plus className="w-4 h-4 mr-2" />
                New Meeting
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Meeting Creation Form */}
          <div className="lg:col-span-2">
            <MeetingForm 
              referenceTime={referenceTime}
              onReferenceTimeChange={setReferenceTime}
            />
          </div>

          {/* Time Zone Comparison */}
          <div className="space-y-6">
            <TimezoneComparison 
              selectedTimeZones={selectedTimeZones}
              onTimeZonesChange={setSelectedTimeZones}
              referenceTime={referenceTime}
            />
          </div>
        </div>

        {/* Recent Meetings */}
        <div className="mt-12">
          <RecentMeetings />
        </div>
      </main>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button
          size="lg"
          className="w-14 h-14 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition-all hover:scale-105 p-0"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}
