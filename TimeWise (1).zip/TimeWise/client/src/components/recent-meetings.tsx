import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type Meeting } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Users, Edit, Share, Trash2 } from "lucide-react";
import { format } from "date-fns";

export default function RecentMeetings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: meetings = [], isLoading } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
  });

  const deleteMeetingMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/meetings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      toast({
        title: "Meeting deleted",
        description: "The meeting has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete meeting",
      });
    }
  });

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this meeting?")) {
      deleteMeetingMutation.mutate(id);
    }
  };

  const handleShare = (meeting: Meeting) => {
    const shareText = `Meeting: ${meeting.title}\nDate: ${meeting.date}\nTime: ${meeting.time}\nDuration: ${meeting.duration} minutes`;
    
    if (navigator.share) {
      navigator.share({
        title: meeting.title,
        text: shareText,
      });
    } else {
      navigator.clipboard.writeText(shareText);
      toast({
        title: "Meeting details copied",
        description: "Meeting details have been copied to clipboard.",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled": return "bg-emerald-100 text-emerald-800";
      case "completed": return "bg-blue-100 text-blue-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-amber-100 text-amber-800";
    }
  };

  const formatMeetingDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return format(date, "MMM d, yyyy");
    } catch {
      return dateStr;
    }
  };

  const formatMeetingTime = (timeStr: string) => {
    try {
      const [hours, minutes] = timeStr.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return format(date, "h:mm a");
    } catch {
      return timeStr;
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-xl border border-slate-200 p-6">
            <div className="animate-pulse space-y-3">
              <div className="h-4 bg-slate-200 rounded w-1/3"></div>
              <div className="h-3 bg-slate-200 rounded w-2/3"></div>
              <div className="h-3 bg-slate-200 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-slate-900">Recent Meetings</h2>
        <Button variant="ghost" className="text-blue-600 hover:text-blue-700">
          View All
        </Button>
      </div>

      {meetings.length === 0 ? (
        <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
          <CardContent className="p-8 text-center">
            <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-2">No meetings yet</h3>
            <p className="text-slate-500">Create your first meeting to get started with scheduling across time zones.</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          {meetings.map((meeting, index) => (
            <div 
              key={meeting.id}
              className={`p-6 hover:bg-slate-50 transition-colors ${
                index < meetings.length - 1 ? "border-b border-slate-200" : ""
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-base font-medium text-slate-900 mb-1">
                    {meeting.title}
                  </h3>
                  {meeting.description && (
                    <p className="text-sm text-slate-500 mb-2">
                      {meeting.description}
                    </p>
                  )}
                  
                  <div className="flex items-center space-x-4 text-xs text-slate-500">
                    <span className="flex items-center">
                      <Calendar className="w-3 h-3 mr-1" />
                      {formatMeetingDate(meeting.date)}
                    </span>
                    <span className="flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {formatMeetingTime(meeting.time)}
                    </span>
                    <span className="flex items-center">
                      <Users className="w-3 h-3 mr-1" />
                      {meeting.duration} min
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <Badge className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(meeting.status)}`}>
                    {meeting.status.charAt(0).toUpperCase() + meeting.status.slice(1)}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="p-1 text-slate-400 hover:text-slate-600"
                      onClick={() => console.log("Edit meeting", meeting.id)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="p-1 text-slate-400 hover:text-slate-600"
                      onClick={() => handleShare(meeting)}
                    >
                      <Share className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="p-1 text-slate-400 hover:text-red-600"
                      onClick={() => handleDelete(meeting.id)}
                      disabled={deleteMeetingMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
