import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, storage } from '@/lib/firebase';
import { Product, Purchase, ProductFormData } from '../../../shared/types';

// Collections
const PRODUCTS_COLLECTION = 'products';
const PURCHASES_COLLECTION = 'purchases';

// Product operations
export async function createProduct(
  productData: ProductFormData,
  bannerFile: File,
  extraFiles: File[],
  adminEmail: string,
  upiQrFile?: File,
  productFile?: File
): Promise<string> {
  try {
    // Upload banner image
    const bannerRef = ref(storage, `products/${Date.now()}_banner_${bannerFile.name}`);
    await uploadBytes(bannerRef, bannerFile);
    const bannerUrl = await getDownloadURL(bannerRef);

    // Upload extra images
    const extraImageUrls: string[] = [];
    for (const file of extraFiles) {
      const imageRef = ref(storage, `products/${Date.now()}_extra_${file.name}`);
      await uploadBytes(imageRef, file);
      const imageUrl = await getDownloadURL(imageRef);
      extraImageUrls.push(imageUrl);
    }

    // Upload UPI QR if provided
    let upiQrUrl = '';
    if (upiQrFile) {
      const qrRef = ref(storage, `products/${Date.now()}_qr_${upiQrFile.name}`);
      await uploadBytes(qrRef, upiQrFile);
      upiQrUrl = await getDownloadURL(qrRef);
    }

    // Upload product file if provided
    let fileUrl = '';
    if (productFile) {
      const fileRef = ref(storage, `products/${Date.now()}_file_${productFile.name}`);
      await uploadBytes(fileRef, productFile);
      fileUrl = await getDownloadURL(fileRef);
    }

    // Create product document
    const productDoc = {
      title: productData.title,
      description: productData.description,
      price: productData.price,
      bannerUrl,
      extraImages: extraImageUrls,
      upiId: productData.upiId || '',
      upiQrUrl,
      fileUrl,
      createdAt: serverTimestamp(),
      createdBy: adminEmail
    };

    const docRef = await addDoc(collection(db, PRODUCTS_COLLECTION), productDoc);
    return docRef.id;
  } catch (error) {
    console.error('Error creating product:', error);
    throw error;
  }
}

export async function getProducts(): Promise<Product[]> {
  try {
    const querySnapshot = await getDocs(
      query(collection(db, PRODUCTS_COLLECTION), orderBy('createdAt', 'desc'))
    );
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date()
    } as Product));
  } catch (error) {
    console.error('Error fetching products:', error);
    throw error;
  }
}

export async function getProduct(id: string): Promise<Product | null> {
  try {
    const docSnap = await getDoc(doc(db, PRODUCTS_COLLECTION, id));
    
    if (docSnap.exists()) {
      return {
        id: docSnap.id,
        ...docSnap.data(),
        createdAt: docSnap.data().createdAt?.toDate() || new Date()
      } as Product;
    }
    
    return null;
  } catch (error) {
    console.error('Error fetching product:', error);
    throw error;
  }
}

export async function deleteProduct(id: string): Promise<void> {
  try {
    // Get product data to delete associated files
    const product = await getProduct(id);
    if (product) {
      // Delete banner image
      if (product.bannerUrl) {
        const bannerRef = ref(storage, product.bannerUrl);
        await deleteObject(bannerRef).catch(() => {});
      }

      // Delete extra images
      for (const imageUrl of product.extraImages) {
        const imageRef = ref(storage, imageUrl);
        await deleteObject(imageRef).catch(() => {});
      }

      // Delete UPI QR
      if (product.upiQrUrl) {
        const qrRef = ref(storage, product.upiQrUrl);
        await deleteObject(qrRef).catch(() => {});
      }

      // Delete product file
      if (product.fileUrl) {
        const fileRef = ref(storage, product.fileUrl);
        await deleteObject(fileRef).catch(() => {});
      }
    }

    // Delete the document
    await deleteDoc(doc(db, PRODUCTS_COLLECTION, id));
  } catch (error) {
    console.error('Error deleting product:', error);
    throw error;
  }
}

// Purchase operations
export async function createPurchase(
  productId: string,
  buyerName: string,
  buyerEmail: string,
  screenshotFile: File
): Promise<string> {
  try {
    // Upload screenshot
    const screenshotRef = ref(storage, `purchases/${Date.now()}_${screenshotFile.name}`);
    await uploadBytes(screenshotRef, screenshotFile);
    const screenshotUrl = await getDownloadURL(screenshotRef);

    // Create purchase document
    const purchaseDoc = {
      productId,
      buyerName,
      buyerEmail,
      screenshotUrl,
      approved: false,
      createdAt: serverTimestamp()
    };

    const docRef = await addDoc(collection(db, PURCHASES_COLLECTION), purchaseDoc);
    return docRef.id;
  } catch (error) {
    console.error('Error creating purchase:', error);
    throw error;
  }
}

export async function getPurchases(): Promise<Purchase[]> {
  try {
    const querySnapshot = await getDocs(
      query(collection(db, PURCHASES_COLLECTION), orderBy('createdAt', 'desc'))
    );
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      approvedAt: doc.data().approvedAt?.toDate()
    } as Purchase));
  } catch (error) {
    console.error('Error fetching purchases:', error);
    throw error;
  }
}

export async function getUserPurchases(userEmail: string): Promise<Purchase[]> {
  try {
    const querySnapshot = await getDocs(
      query(
        collection(db, PURCHASES_COLLECTION),
        where('buyerEmail', '==', userEmail),
        orderBy('createdAt', 'desc')
      )
    );
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date(),
      approvedAt: doc.data().approvedAt?.toDate()
    } as Purchase));
  } catch (error) {
    console.error('Error fetching user purchases:', error);
    throw error;
  }
}

export async function approvePurchase(purchaseId: string): Promise<void> {
  try {
    await updateDoc(doc(db, PURCHASES_COLLECTION, purchaseId), {
      approved: true,
      approvedAt: serverTimestamp()
    });
  } catch (error) {
    console.error('Error approving purchase:', error);
    throw error;
  }
}

export async function getApprovedPurchase(productId: string, userEmail: string): Promise<Purchase | null> {
  try {
    const querySnapshot = await getDocs(
      query(
        collection(db, PURCHASES_COLLECTION),
        where('productId', '==', productId),
        where('buyerEmail', '==', userEmail),
        where('approved', '==', true)
      )
    );
    
    if (!querySnapshot.empty) {
      const doc = querySnapshot.docs[0];
      return {
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        approvedAt: doc.data().approvedAt?.toDate()
      } as Purchase;
    }
    
    return null;
  } catch (error) {
    console.error('Error checking approved purchase:', error);
    throw error;
  }
}