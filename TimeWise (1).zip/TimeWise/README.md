# Clash Store - Digital Product Marketplace

A modern digital product store built with React, TypeScript, and Firebase. Features secure admin panel, UPI-based payments, and manual approval system.

## Features

### 🔐 Admin Panel
- Google authentication restricted to specific admin email
- Upload products with images, descriptions, and files
- Set UPI payment details and QR codes
- Generate unique product links
- View and approve purchase requests
- Dashboard with sales analytics

### 🛍️ Customer Experience
- Browse products via unique links
- UPI payment integration with QR codes
- Upload payment screenshots
- Track purchase status
- Download purchased products after approval

### 🔒 Security
- Firebase Authentication with Google sign-in
- Firestore security rules restricting admin access
- File access control based on purchase approval
- Manual payment verification system

## Setup Instructions

### 1. Firebase Configuration
1. Create a new Firebase project at https://console.firebase.google.com/
2. Enable Authentication and select Google sign-in method
3. Enable Firestore Database
4. Enable Storage for file uploads
5. Copy your Firebase config credentials and add them as secrets:
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_PROJECT_ID` 
   - `VITE_FIREBASE_APP_ID`

### 2. Update Admin Email
1. Open `client/src/lib/firebase.ts`
2. Replace `'your-admin@gmail.com'` with your actual Gmail address
3. Update the same email in `firestore.rules`

### 3. Deploy Firestore Rules
1. Install Firebase CLI: `npm install -g firebase-tools`
2. Run `firebase login` and select your project
3. Deploy rules: `firebase deploy --only firestore:rules`
4. Deploy storage rules from the Firebase console

### 4. Start Development
```bash
npm run dev
```

## Usage

### For Admin
1. Sign in with the configured admin Gmail
2. Access admin panel to create products
3. Upload product images, set prices, add UPI details
4. Generate shareable product links
5. Review and approve purchase requests

### For Customers
1. Visit unique product links shared by admin
2. Sign in with Google to purchase
3. Make UPI payment and upload screenshot
4. Wait for admin approval
5. Download product files once approved

## File Structure

```
├── client/src/
│   ├── pages/           # Main application pages
│   │   ├── login.tsx           # Authentication page
│   │   ├── admin-dashboard.tsx # Admin control panel
│   │   ├── product-page.tsx    # Public product display
│   │   └── my-purchases.tsx    # Customer purchase history
│   ├── services/        # Firebase integration
│   ├── hooks/           # React hooks
│   └── lib/             # Utilities and Firebase config
├── shared/              # TypeScript types
└── firestore.rules      # Firebase security rules
```

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **UI Components**: shadcn/ui, Radix UI
- **Authentication**: Firebase Auth
- **Database**: Firebase Firestore
- **Storage**: Firebase Storage
- **Routing**: Wouter
- **Build Tool**: Vite

## Payment Flow

1. Customer views product and clicks "Buy Now"
2. Payment instructions shown with UPI ID/QR code
3. Customer makes payment via UPI app
4. Customer uploads payment screenshot
5. Admin reviews screenshot in dashboard
6. Admin approves purchase
7. Customer gets access to download product file

## Security Features

- Google Authentication required for all actions
- Admin access restricted to specific Gmail address
- Firestore rules prevent unauthorized data access
- File downloads only after purchase approval
- Manual payment verification system