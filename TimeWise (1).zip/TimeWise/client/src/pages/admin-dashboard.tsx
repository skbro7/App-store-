import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { 
  getProducts, 
  getPurchases, 
  createProduct, 
  deleteProduct, 
  approvePurchase 
} from '@/services/firestore';
import { Product, Purchase, ProductFormData } from '../../../shared/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  ArrowLeft, 
  Upload, 
  Trash2, 
  Check, 
  X, 
  Eye,
  Store,
  ShoppingBag,
  Users,
  DollarSign
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { user, loading, isAdmin } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [loadingPurchases, setLoadingPurchases] = useState(true);

  // Form state
  const [formData, setFormData] = useState<ProductFormData>({
    title: '',
    description: '',
    price: 0,
    upiId: ''
  });
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [extraFiles, setExtraFiles] = useState<File[]>([]);
  const [upiQrFile, setUpiQrFile] = useState<File | null>(null);
  const [productFile, setProductFile] = useState<File | null>(null);

  useEffect(() => {
    if (!loading && !isAdmin) {
      setLocation('/');
      return;
    }

    if (isAdmin) {
      loadData();
    }
  }, [loading, isAdmin, setLocation]);

  const loadData = async () => {
    try {
      const [productsData, purchasesData] = await Promise.all([
        getProducts(),
        getPurchases()
      ]);
      setProducts(productsData);
      setPurchases(purchasesData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load data"
      });
    } finally {
      setLoadingProducts(false);
      setLoadingPurchases(false);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bannerFile || !user?.email) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Banner image is required"
      });
      return;
    }

    setIsCreating(true);
    try {
      await createProduct(
        formData,
        bannerFile,
        extraFiles,
        user.email,
        upiQrFile || undefined,
        productFile || undefined
      );

      toast({
        title: "Product created",
        description: "Product has been created successfully"
      });

      // Reset form
      setFormData({ title: '', description: '', price: 0, upiId: '' });
      setBannerFile(null);
      setExtraFiles([]);
      setUpiQrFile(null);
      setProductFile(null);
      
      // Reload data
      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create product"
      });
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      await deleteProduct(id);
      toast({
        title: "Product deleted",
        description: "Product has been deleted successfully"
      });
      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete product"
      });
    }
  };

  const handleApprovePurchase = async (purchaseId: string) => {
    try {
      await approvePurchase(purchaseId);
      toast({
        title: "Purchase approved",
        description: "User can now access the product"
      });
      loadData();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to approve purchase"
      });
    }
  };

  const generateProductLink = (productId: string) => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/product/${productId}`;
  };

  if (loading || !isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation('/')}
                className="text-gray-600 hover:text-gray-800"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Store className="text-white w-5 h-5" />
                </div>
                <h1 className="text-xl font-semibold text-gray-900">Admin Dashboard</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <img 
                src={user?.photoURL || ''} 
                alt={user?.displayName || 'User'} 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm font-medium text-gray-700">
                {user?.displayName}
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Products</p>
                  <p className="text-2xl font-bold text-gray-900">{products.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <ShoppingBag className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Purchases</p>
                  <p className="text-2xl font-bold text-gray-900">{purchases.length}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ₹{purchases.filter(p => p.approved).reduce((sum, p) => {
                      const product = products.find(pr => pr.id === p.productId);
                      return sum + (product?.price || 0);
                    }, 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Create Product Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="w-5 h-5" />
                <span>Create New Product</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateProduct} className="space-y-4">
                <div>
                  <Label htmlFor="title">Product Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Enter product title"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter product description"
                    rows={3}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="price">Price (₹)</Label>
                  <Input
                    id="price"
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    placeholder="Enter price in INR"
                    min="0"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="upiId">UPI ID (Optional)</Label>
                  <Input
                    id="upiId"
                    value={formData.upiId}
                    onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
                    placeholder="your-upi@paytm"
                  />
                </div>

                <div>
                  <Label htmlFor="banner">Banner Image *</Label>
                  <Input
                    id="banner"
                    type="file"
                    accept="image/*"
                    onChange={(e) => setBannerFile(e.target.files?.[0] || null)}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="extra">Extra Images</Label>
                  <Input
                    id="extra"
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={(e) => setExtraFiles(Array.from(e.target.files || []))}
                  />
                </div>

                <div>
                  <Label htmlFor="qr">UPI QR Code</Label>
                  <Input
                    id="qr"
                    type="file"
                    accept="image/*"
                    onChange={(e) => setUpiQrFile(e.target.files?.[0] || null)}
                  />
                </div>

                <div>
                  <Label htmlFor="file">Product File</Label>
                  <Input
                    id="file"
                    type="file"
                    onChange={(e) => setProductFile(e.target.files?.[0] || null)}
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isCreating}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {isCreating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Creating...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Create Product
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Products List */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Products ({products.length})</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingProducts ? (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                  </div>
                ) : products.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">No products created yet</p>
                ) : (
                  <div className="space-y-4">
                    {products.map((product) => (
                      <div key={product.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{product.title}</h4>
                            <p className="text-sm text-gray-600 mt-1">₹{product.price}</p>
                            <div className="flex items-center space-x-2 mt-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  const link = generateProductLink(product.id);
                                  navigator.clipboard.writeText(link);
                                  toast({
                                    title: "Link copied",
                                    description: "Product link copied to clipboard"
                                  });
                                }}
                              >
                                <Eye className="w-3 h-3 mr-1" />
                                Copy Link
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeleteProduct(product.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <img 
                            src={product.bannerUrl} 
                            alt={product.title}
                            className="w-16 h-16 object-cover rounded-lg ml-4"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Purchase Requests */}
            <Card>
              <CardHeader>
                <CardTitle>Purchase Requests ({purchases.filter(p => !p.approved).length})</CardTitle>
              </CardHeader>
              <CardContent>
                {loadingPurchases ? (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {purchases
                      .filter(purchase => !purchase.approved)
                      .map((purchase) => {
                        const product = products.find(p => p.id === purchase.productId);
                        return (
                          <div key={purchase.id} className="border border-gray-200 rounded-lg p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-medium text-gray-900">{product?.title}</h4>
                                <p className="text-sm text-gray-600">
                                  {purchase.buyerName} ({purchase.buyerEmail})
                                </p>
                                <p className="text-xs text-gray-500 mt-1">
                                  {purchase.createdAt.toLocaleDateString()}
                                </p>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(purchase.screenshotUrl, '_blank')}
                                >
                                  <Eye className="w-3 h-3 mr-1" />
                                  View
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleApprovePurchase(purchase.id)}
                                  className="text-green-600 hover:text-green-700"
                                >
                                  <Check className="w-3 h-3 mr-1" />
                                  Approve
                                </Button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    {purchases.filter(p => !p.approved).length === 0 && (
                      <p className="text-gray-500 text-center py-4">No pending purchase requests</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}