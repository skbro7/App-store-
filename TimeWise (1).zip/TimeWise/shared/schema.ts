import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const meetings = pgTable("meetings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  date: text("date").notNull(), // YYYY-MM-DD format
  time: text("time").notNull(), // HH:MM format
  duration: integer("duration").notNull().default(60), // minutes
  referenceTimezone: text("reference_timezone").notNull(),
  status: text("status").notNull().default("draft"), // draft, scheduled, completed, cancelled
});

export const insertMeetingSchema = createInsertSchema(meetings).omit({
  id: true,
}).extend({
  title: z.string().min(1, "Title is required"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format"),
  time: z.string().regex(/^\d{2}:\d{2}$/, "Invalid time format"),
  duration: z.number().min(15).max(480),
  referenceTimezone: z.string().min(1, "Time zone is required"),
  status: z.enum(["draft", "scheduled", "completed", "cancelled"]).default("draft"),
});

export type InsertMeeting = z.infer<typeof insertMeetingSchema>;
export type Meeting = typeof meetings.$inferSelect;
