import { type Meeting, type InsertMeeting } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Meeting operations
  getMeeting(id: string): Promise<Meeting | undefined>;
  getAllMeetings(): Promise<Meeting[]>;
  createMeeting(meeting: InsertMeeting): Promise<Meeting>;
  updateMeeting(id: string, meeting: Partial<InsertMeeting>): Promise<Meeting | undefined>;
  deleteMeeting(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private meetings: Map<string, Meeting>;

  constructor() {
    this.meetings = new Map();
    this.seedData();
  }

  private seedData() {
    // Add some sample meetings for demonstration
    const sampleMeetings: Meeting[] = [
      {
        id: randomUUID(),
        title: "Weekly Team Sync",
        description: "Review project progress and upcoming milestones",
        date: "2024-12-15",
        time: "14:00",
        duration: 60,
        referenceTimezone: "America/Los_Angeles",
        status: "scheduled"
      },
      {
        id: randomUUID(),
        title: "Client Presentation",
        description: "Present Q4 results and discuss 2025 strategy",
        date: "2024-12-18",
        time: "10:00",
        duration: 90,
        referenceTimezone: "America/Los_Angeles",
        status: "scheduled"
      },
      {
        id: randomUUID(),
        title: "Product Demo",
        description: "Demo new features to stakeholders",
        date: "2024-12-20",
        time: "15:00",
        duration: 45,
        referenceTimezone: "America/Los_Angeles",
        status: "draft"
      }
    ];

    sampleMeetings.forEach(meeting => {
      this.meetings.set(meeting.id, meeting);
    });
  }

  async getMeeting(id: string): Promise<Meeting | undefined> {
    return this.meetings.get(id);
  }

  async getAllMeetings(): Promise<Meeting[]> {
    return Array.from(this.meetings.values()).sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateB.getTime() - dateA.getTime();
    });
  }

  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const id = randomUUID();
    const meeting: Meeting = { ...insertMeeting, id };
    this.meetings.set(id, meeting);
    return meeting;
  }

  async updateMeeting(id: string, updateData: Partial<InsertMeeting>): Promise<Meeting | undefined> {
    const existing = this.meetings.get(id);
    if (!existing) {
      return undefined;
    }
    
    const updated: Meeting = { ...existing, ...updateData };
    this.meetings.set(id, updated);
    return updated;
  }

  async deleteMeeting(id: string): Promise<boolean> {
    return this.meetings.delete(id);
  }
}

export const storage = new MemStorage();
