export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  bannerUrl: string;
  extraImages: string[];
  upiId?: string;
  upiQrUrl?: string;
  fileUrl?: string;
  createdAt: Date;
  createdBy: string;
}

export interface Purchase {
  id: string;
  productId: string;
  buyerName: string;
  buyerEmail: string;
  screenshotUrl: string;
  approved: boolean;
  createdAt: Date;
  approvedAt?: Date;
}

export interface User {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
}

export interface ProductFormData {
  title: string;
  description: string;
  price: number;
  upiId?: string;
}