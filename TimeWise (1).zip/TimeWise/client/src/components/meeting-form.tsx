import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertMeetingSchema, type InsertMeeting } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TIMEZONES } from "@/lib/timezones";

interface MeetingFormProps {
  referenceTime: {
    date: string;
    time: string;
    timezone: string;
  };
  onReferenceTimeChange: (time: { date: string; time: string; timezone: string }) => void;
}

export default function MeetingForm({ referenceTime, onReferenceTimeChange }: MeetingFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertMeeting>({
    resolver: zodResolver(insertMeetingSchema),
    defaultValues: {
      title: "",
      description: "",
      date: referenceTime.date,
      time: referenceTime.time,
      duration: 60,
      referenceTimezone: referenceTime.timezone,
      status: "draft"
    }
  });

  const createMeetingMutation = useMutation({
    mutationFn: async (data: InsertMeeting) => {
      const response = await apiRequest("POST", "/api/meetings", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      toast({
        title: "Meeting created",
        description: "Your meeting has been created successfully.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create meeting",
      });
    }
  });

  const onSubmit = (data: InsertMeeting) => {
    createMeetingMutation.mutate(data);
  };

  const saveDraftMutation = useMutation({
    mutationFn: async (data: InsertMeeting) => {
      const response = await apiRequest("POST", "/api/meetings", { ...data, status: "draft" });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      toast({
        title: "Draft saved",
        description: "Your meeting draft has been saved.",
      });
    }
  });

  const saveDraft = () => {
    const data = form.getValues();
    saveDraftMutation.mutate({ ...data, status: "draft" });
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
      <CardContent className="p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-6">Create New Meeting</h2>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <Label htmlFor="title" className="block text-sm font-medium text-slate-700 mb-2">
              Meeting Title
            </Label>
            <Input 
              id="title"
              placeholder="Enter meeting title..."
              {...form.register("title")}
              className="w-full"
            />
            {form.formState.errors.title && (
              <p className="text-red-500 text-sm mt-1">{form.formState.errors.title.message}</p>
            )}
          </div>

          <div>
            <Label htmlFor="description" className="block text-sm font-medium text-slate-700 mb-2">
              Description
            </Label>
            <Textarea 
              id="description"
              rows={3}
              placeholder="Add meeting description, agenda, or notes..."
              {...form.register("description")}
              className="w-full resize-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="date" className="block text-sm font-medium text-slate-700 mb-2">
                Date
              </Label>
              <Input 
                id="date"
                type="date" 
                {...form.register("date")}
                onChange={(e) => {
                  form.setValue("date", e.target.value);
                  onReferenceTimeChange({...referenceTime, date: e.target.value});
                }}
                className="w-full"
              />
            </div>
            <div>
              <Label htmlFor="duration" className="block text-sm font-medium text-slate-700 mb-2">
                Duration
              </Label>
              <Select 
                value={form.watch("duration")?.toString()}
                onValueChange={(value) => form.setValue("duration", parseInt(value))}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="45">45 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="90">1.5 hours</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="timezone" className="block text-sm font-medium text-slate-700 mb-2">
              Time Zone Reference
            </Label>
            <Select 
              value={form.watch("referenceTimezone")}
              onValueChange={(value) => {
                form.setValue("referenceTimezone", value);
                onReferenceTimeChange({...referenceTime, timezone: value});
              }}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select time zone" />
              </SelectTrigger>
              <SelectContent>
                {TIMEZONES.map((tz) => (
                  <SelectItem key={tz.value} value={tz.value}>
                    {tz.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="time" className="block text-sm font-medium text-slate-700 mb-2">
              Preferred Time
            </Label>
            <Input 
              id="time"
              type="time" 
              {...form.register("time")}
              onChange={(e) => {
                form.setValue("time", e.target.value);
                onReferenceTimeChange({...referenceTime, time: e.target.value});
              }}
              className="w-full"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <Button 
              type="button" 
              variant="ghost"
              onClick={saveDraft}
              disabled={saveDraftMutation.isPending}
              className="text-slate-600 hover:text-slate-800"
            >
              Save as Draft
            </Button>
            <div className="flex space-x-3">
              <Button type="button" variant="outline" className="border-slate-300 text-slate-700 hover:bg-slate-50">
                Preview
              </Button>
              <Button 
                type="submit" 
                disabled={createMeetingMutation.isPending}
                className="bg-blue-500 hover:bg-blue-600 text-white shadow-sm"
              >
                {createMeetingMutation.isPending ? "Creating..." : "Create Meeting"}
              </Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
