export const TIMEZONES = [
  {
    value: "America/Los_Angeles",
    label: "San Francisco (PST/PDT)",
    shortLabel: "PST",
    city: "San Francisco"
  },
  {
    value: "America/New_York", 
    label: "New York (EST/EDT)",
    shortLabel: "EST",
    city: "New York"
  },
  {
    value: "Europe/London",
    label: "London (GMT/BST)",
    shortLabel: "GMT",
    city: "London"
  },
  {
    value: "Asia/Tokyo",
    label: "Tokyo (JST)",
    shortLabel: "JST", 
    city: "Tokyo"
  },
  {
    value: "Australia/Sydney",
    label: "Sydney (AEST/AEDT)",
    shortLabel: "AEST",
    city: "Sydney"
  },
  {
    value: "Europe/Paris",
    label: "Paris (CET/CEST)",
    shortLabel: "CET",
    city: "Paris"
  },
  {
    value: "Asia/Singapore",
    label: "Singapore (SGT)",
    shortLabel: "SGT",
    city: "Singapore"
  },
  {
    value: "America/Chicago",
    label: "Chicago (CST/CDT)",
    shortLabel: "CST",
    city: "Chicago"
  },
  {
    value: "Europe/Berlin",
    label: "Berlin (CET/CEST)",
    shortLabel: "CET",
    city: "Berlin"
  },
  {
    value: "Asia/Dubai",
    label: "Dubai (GST)",
    shortLabel: "GST",
    city: "Dubai"
  }
];

export function formatTimeInTimezone(date: Date, timezone: string): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
    
    const timeString = formatter.format(date);
    
    // Check if it's the next day
    const localDate = new Date(date.toLocaleString('en-US', { timeZone: timezone }));
    const originalDate = new Date(date);
    
    if (localDate.getDate() !== originalDate.getDate()) {
      const dayDiff = localDate.getDate() - originalDate.getDate();
      return dayDiff > 0 ? `${timeString} +1` : `${timeString} -1`;
    }
    
    return timeString;
  } catch (error) {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  }
}

export function isBusinessHours(timeString: string): boolean {
  // Remove +1/-1 day indicators
  const cleanTime = timeString.replace(/\s[+-]\d+$/, '');
  
  try {
    const time = new Date(`1970-01-01 ${cleanTime}`);
    const hours = time.getHours();
    
    // Business hours: 9 AM to 6 PM
    return hours >= 9 && hours < 18;
  } catch {
    return false;
  }
}

export function getTimezoneOffset(timezone: string): number {
  try {
    const now = new Date();
    const utc = new Date(now.getTime() + (now.getTimezoneOffset() * 60000));
    const tz = new Date(utc.toLocaleString('en-US', { timeZone: timezone }));
    return (tz.getTime() - utc.getTime()) / (1000 * 60 * 60);
  } catch {
    return 0;
  }
}
