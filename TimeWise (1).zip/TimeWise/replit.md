# Clash Store - Digital Product Store

## Overview

This is a digital product marketplace built with React, TypeScript, and Firebase. The application enables an admin to upload digital products and manage sales, while customers can purchase products via UPI payment and get access after admin approval. Features Firebase Authentication, Firestore database, and Firebase Storage for file management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom gradients and glass morphism effects
- **Authentication**: Firebase Auth with Google sign-in
- **State Management**: React hooks with Firebase real-time listeners
- **Build Tool**: Vite for development and bundling

### Backend Architecture
- **Database**: Firebase Firestore (NoSQL document database)
- **Authentication**: Firebase Authentication with Google provider
- **Storage**: Firebase Storage for images and files
- **Security**: Firestore security rules restricting admin access
- **Real-time**: Firebase real-time updates for data synchronization

## Key Components

### Data Layer
- **Database**: PostgreSQL with Drizzle ORM
- **Schema**: Centralized in `shared/schema.ts` for type safety
- **Migrations**: Managed through Drizzle Kit
- **Storage Interface**: Abstract storage interface allowing for different implementations

### Frontend Components
- **Dashboard**: Main application interface
- **Meeting Form**: Form for creating and editing meetings
- **Timezone Comparison**: Interactive timezone converter
- **Recent Meetings**: List of meetings with CRUD operations
- **UI Components**: Comprehensive set of shadcn/ui components

### Backend Services
- **Routes**: RESTful API endpoints for meeting management
- **Storage**: Pluggable storage system (currently in-memory, designed for PostgreSQL)
- **Validation**: Request validation using shared Zod schemas

## Data Flow

1. **Meeting Creation**: User fills out meeting form → Frontend validates with Zod → API request to backend → Backend validates → Store in database → Return success/error
2. **Meeting Display**: Frontend queries API → Backend retrieves from storage → Return meeting data → Frontend displays with timezone conversions
3. **Timezone Calculations**: Frontend calculates timezone conversions in real-time using browser's Intl API

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React, Radix UI primitives
- **Styling**: Tailwind CSS, class-variance-authority for component variants
- **State Management**: TanStack Query for server state
- **Forms**: React Hook Form, hookform/resolvers
- **Date/Time**: date-fns for date manipulation
- **Routing**: wouter for lightweight routing

### Backend Dependencies
- **Database**: Neon serverless PostgreSQL driver
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod for schema validation
- **Session**: connect-pg-simple for PostgreSQL session store

### Development Tools
- **Build**: Vite, esbuild for production builds
- **TypeScript**: Strict configuration with path mapping
- **Linting**: ESBuild for fast compilation

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds React app to `dist/public`
2. **Backend**: esbuild bundles Express server to `dist/index.js`
3. **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Development**: Uses tsx for TypeScript execution, Vite dev server
- **Production**: Node.js serves bundled Express app with static files
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Project Structure
```
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Route components
│   │   ├── lib/         # Utilities and configs
│   │   └── hooks/       # Custom React hooks
├── server/          # Express backend
│   ├── routes.ts    # API endpoints
│   ├── storage.ts   # Data access layer
│   └── vite.ts      # Development server setup
├── shared/          # Shared TypeScript code
│   └── schema.ts    # Zod schemas and types
└── migrations/      # Database migrations
```

### Key Architectural Decisions

1. **Monorepo Structure**: Frontend, backend, and shared code in single repository for easier development and type sharing
2. **TypeScript Everywhere**: Full type safety across the entire stack
3. **Shared Schemas**: Zod schemas defined once and used for both frontend validation and backend API validation
4. **Pluggable Storage**: Abstract storage interface allows switching between in-memory (development) and PostgreSQL (production)
5. **Component-Based UI**: shadcn/ui provides consistent, accessible components with Tailwind styling
6. **Server State Management**: TanStack Query handles API calls, caching, and synchronization
7. **Time Zone Handling**: Client-side timezone calculations using browser APIs for better user experience