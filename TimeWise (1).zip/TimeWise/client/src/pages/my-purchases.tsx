import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { getUserPurchases, getProducts } from '@/services/firestore';
import { Purchase, Product } from '../../../shared/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Download, 
  Clock, 
  CheckCircle,
  X,
  Store,
  ShoppingBag
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function MyPurchases() {
  const [, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingPurchases, setLoadingPurchases] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      setLocation('/');
      return;
    }

    if (user?.email) {
      loadUserPurchases();
    }
  }, [loading, user, setLocation]);

  const loadUserPurchases = async () => {
    if (!user?.email) return;

    try {
      const [purchasesData, productsData] = await Promise.all([
        getUserPurchases(user.email),
        getProducts()
      ]);
      
      setPurchases(purchasesData);
      setProducts(productsData);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load your purchases"
      });
    } finally {
      setLoadingPurchases(false);
    }
  };

  const handleDownload = (product: Product) => {
    if (product.fileUrl) {
      window.open(product.fileUrl, '_blank');
    } else {
      toast({
        variant: "destructive",
        title: "No file available",
        description: "This product doesn't have a downloadable file"
      });
    }
  };

  const getProduct = (productId: string): Product | undefined => {
    return products.find(p => p.id === productId);
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation('/')}
                className="text-gray-600 hover:text-gray-800"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Store className="text-white w-5 h-5" />
                </div>
                <h1 className="text-xl font-semibold text-gray-900">My Purchases</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <img 
                src={user.photoURL || ''} 
                alt={user.displayName || 'User'} 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm font-medium text-gray-700">
                {user.displayName}
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loadingPurchases ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading your purchases...</p>
          </div>
        ) : purchases.length === 0 ? (
          /* Empty state */
          <Card className="text-center py-12">
            <CardContent>
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingBag className="w-8 h-8 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">No purchases yet</h2>
              <p className="text-gray-600 mb-6">
                You haven't made any purchases yet. Browse products to get started.
              </p>
              <Button 
                onClick={() => setLocation('/')}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Browse Products
              </Button>
            </CardContent>
          </Card>
        ) : (
          /* Purchases list */
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">
                Your Purchases ({purchases.length})
              </h2>
            </div>

            <div className="grid gap-6">
              {purchases.map((purchase) => {
                const product = getProduct(purchase.productId);
                
                if (!product) {
                  return (
                    <Card key={purchase.id} className="border-gray-200">
                      <CardContent className="p-6">
                        <div className="text-center text-gray-500">
                          Product information not available
                        </div>
                      </CardContent>
                    </Card>
                  );
                }

                return (
                  <Card key={purchase.id} className="border-gray-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        {/* Product Image */}
                        <div className="w-20 h-20 flex-shrink-0">
                          <img 
                            src={product.bannerUrl} 
                            alt={product.title}
                            className="w-full h-full object-cover rounded-lg"
                          />
                        </div>

                        {/* Product Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="text-lg font-semibold text-gray-900 mb-1">
                                {product.title}
                              </h3>
                              <p className="text-sm text-gray-600 mb-2">
                                ₹{product.price}
                              </p>
                              <p className="text-xs text-gray-500">
                                Purchased on {purchase.createdAt.toLocaleDateString()}
                              </p>
                            </div>

                            {/* Status and Actions */}
                            <div className="flex flex-col items-end space-y-3">
                              {purchase.approved ? (
                                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  Approved
                                </Badge>
                              ) : (
                                <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                                  <Clock className="w-3 h-3 mr-1" />
                                  Pending
                                </Badge>
                              )}

                              <div className="flex space-x-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(purchase.screenshotUrl, '_blank')}
                                >
                                  View Receipt
                                </Button>

                                {purchase.approved && product.fileUrl && (
                                  <Button
                                    size="sm"
                                    onClick={() => handleDownload(product)}
                                    className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                                  >
                                    <Download className="w-3 h-3 mr-1" />
                                    Download
                                  </Button>
                                )}

                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setLocation(`/product/${product.id}`)}
                                >
                                  View Product
                                </Button>
                              </div>
                            </div>
                          </div>

                          {/* Purchase Status Message */}
                          <div className="mt-4 p-3 rounded-lg bg-gray-50">
                            {purchase.approved ? (
                              <div className="flex items-center text-sm text-green-700">
                                <CheckCircle className="w-4 h-4 mr-2 flex-shrink-0" />
                                <div>
                                  <p className="font-medium">Purchase approved!</p>
                                  <p className="text-green-600">
                                    Approved on {purchase.approvedAt?.toLocaleDateString()}
                                    {product.fileUrl && ' • Ready for download'}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <div className="flex items-center text-sm text-yellow-700">
                                <Clock className="w-4 h-4 mr-2 flex-shrink-0" />
                                <div>
                                  <p className="font-medium">Awaiting approval</p>
                                  <p className="text-yellow-600">
                                    Your payment screenshot is being reviewed. You'll get access once approved.
                                  </p>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}