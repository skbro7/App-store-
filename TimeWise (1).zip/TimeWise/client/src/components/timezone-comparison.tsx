import { useState, useEffect } from "react";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Info } from "lucide-react";
import { TIMEZONES, formatTimeInTimezone, isBusinessHours } from "@/lib/timezones";

interface TimezoneComparisonProps {
  selectedTimeZones: string[];
  onTimeZonesChange: (zones: string[]) => void;
  referenceTime: {
    date: string;
    time: string;
    timezone: string;
  };
}

export default function TimezoneComparison({ 
  selectedTimeZones, 
  onTimeZonesChange, 
  referenceTime 
}: TimezoneComparisonProps) {
  const [showAddTimezone, setShowAddTimezone] = useState(false);
  const [newTimezone, setNewTimezone] = useState("");

  const addTimezone = () => {
    if (newTimezone && !selectedTimeZones.includes(newTimezone)) {
      onTimeZonesChange([...selectedTimeZones, newTimezone]);
      setNewTimezone("");
      setShowAddTimezone(false);
    }
  };

  const removeTimezone = (timezone: string) => {
    onTimeZonesChange(selectedTimeZones.filter(tz => tz !== timezone));
  };

  const getOptimalTimes = () => {
    const referenceDateTime = new Date(`${referenceTime.date}T${referenceTime.time}`);
    
    // Calculate business hour compatibility
    const businessHourZones = selectedTimeZones.filter(tz => {
      const timeInZone = formatTimeInTimezone(referenceDateTime, tz);
      return isBusinessHours(timeInZone);
    });

    const suggestions = [
      {
        label: "Best Option",
        description: `${referenceTime.time} ${TIMEZONES.find(tz => tz.value === referenceTime.timezone)?.shortLabel || referenceTime.timezone}`,
        compatibility: `${businessHourZones.length}/${selectedTimeZones.length} zones`,
        level: businessHourZones.length === selectedTimeZones.length ? "best" : 
               businessHourZones.length >= selectedTimeZones.length * 0.75 ? "good" : "poor"
      }
    ];

    return suggestions;
  };

  const suggestions = getOptimalTimes();

  return (
    <>
      {/* Time Zone Grid */}
      <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Time Zone Comparison</h3>
          
          <div className="space-y-3">
            {selectedTimeZones.map((timezone, index) => {
              const colors = ["bg-blue-500", "bg-emerald-500", "bg-indigo-500", "bg-amber-500"];
              const color = colors[index % colors.length];
              const referenceDateTime = new Date(`${referenceTime.date}T${referenceTime.time}`);
              const timeInZone = formatTimeInTimezone(referenceDateTime, timezone);
              const timezoneInfo = TIMEZONES.find(tz => tz.value === timezone);
              
              return (
                <div key={timezone} className="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 ${color} rounded-full`}></div>
                    <span className="text-sm font-medium text-slate-900">
                      {timezoneInfo?.city || timezone}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-slate-600">{timeInZone}</span>
                    <button 
                      onClick={() => removeTimezone(timezone)}
                      className="text-slate-400 hover:text-red-500 text-xs"
                    >
                      ×
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {showAddTimezone ? (
            <div className="mt-4 flex space-x-2">
              <Select value={newTimezone} onValueChange={setNewTimezone}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Select timezone" />
                </SelectTrigger>
                <SelectContent>
                  {TIMEZONES.filter(tz => !selectedTimeZones.includes(tz.value)).map((tz) => (
                    <SelectItem key={tz.value} value={tz.value}>
                      {tz.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={addTimezone} size="sm">Add</Button>
              <Button 
                onClick={() => setShowAddTimezone(false)} 
                variant="outline" 
                size="sm"
              >
                Cancel
              </Button>
            </div>
          ) : (
            <Button 
              onClick={() => setShowAddTimezone(true)}
              variant="ghost"
              className="w-full mt-4 text-blue-600 hover:text-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Time Zone
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Meeting Optimization */}
      <Card className="bg-white rounded-xl shadow-sm border border-slate-200">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Optimal Times</h3>
          
          <div className="space-y-3">
            {suggestions.map((suggestion, index) => (
              <div 
                key={index}
                className={`p-3 rounded-lg border ${
                  suggestion.level === "best" ? "bg-emerald-50 border-emerald-200" :
                  suggestion.level === "good" ? "bg-amber-50 border-amber-200" :
                  "bg-red-50 border-red-200"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-sm font-medium ${
                    suggestion.level === "best" ? "text-emerald-800" :
                    suggestion.level === "good" ? "text-amber-800" :
                    "text-red-800"
                  }`}>
                    {suggestion.label}
                  </span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    suggestion.level === "best" ? "text-emerald-600 bg-emerald-100" :
                    suggestion.level === "good" ? "text-amber-600 bg-amber-100" :
                    "text-red-600 bg-red-100"
                  }`}>
                    {suggestion.compatibility}
                  </span>
                </div>
                <p className={`text-sm ${
                  suggestion.level === "best" ? "text-emerald-700" :
                  suggestion.level === "good" ? "text-amber-700" :
                  "text-red-700"
                }`}>
                  {suggestion.description}
                </p>
              </div>
            ))}
          </div>

          <div className="flex items-start space-x-2 mt-3 text-xs text-slate-500">
            <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
            <p>Based on standard business hours (9 AM - 6 PM)</p>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
