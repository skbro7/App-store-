import { useState, useEffect } from 'react';
import { useParams } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { getProduct, createPurchase, getApprovedPurchase } from '@/services/firestore';
import { Product, Purchase } from '../../../shared/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Upload, 
  Download, 
  ShoppingCart, 
  CheckCircle,
  Store,
  IndianRupee
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function ProductPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [approvedPurchase, setApprovedPurchase] = useState<Purchase | null>(null);
  const [loading, setLoading] = useState(true);
  const [purchasing, setPurchasing] = useState(false);
  
  // Purchase form state
  const [buyerName, setBuyerName] = useState('');
  const [buyerEmail, setBuyerEmail] = useState('');
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [showPurchaseForm, setShowPurchaseForm] = useState(false);

  useEffect(() => {
    if (id) {
      loadProduct();
    }
  }, [id]);

  useEffect(() => {
    if (user?.email) {
      setBuyerEmail(user.email);
      setBuyerName(user.displayName || '');
    }
  }, [user]);

  const loadProduct = async () => {
    if (!id) return;
    
    try {
      const productData = await getProduct(id);
      setProduct(productData);
      
      // Check if user has approved purchase
      if (user?.email && productData) {
        const approved = await getApprovedPurchase(productData.id, user.email);
        setApprovedPurchase(approved);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load product"
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!product || !screenshotFile || !buyerName || !buyerEmail) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill all fields and upload payment screenshot"
      });
      return;
    }

    setPurchasing(true);
    try {
      await createPurchase(product.id, buyerName, buyerEmail, screenshotFile);
      
      toast({
        title: "Purchase submitted!",
        description: "Your payment screenshot has been submitted. You'll get access once approved."
      });

      setShowPurchaseForm(false);
      setBuyerName('');
      setBuyerEmail(user?.email || '');
      setScreenshotFile(null);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error", 
        description: "Failed to submit purchase"
      });
    } finally {
      setPurchasing(false);
    }
  };

  const handleDownload = () => {
    if (product?.fileUrl) {
      window.open(product.fileUrl, '_blank');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md text-center">
          <CardContent className="p-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Product not found</h2>
            <p className="text-gray-600 mb-4">The product you're looking for doesn't exist.</p>
            <Button onClick={() => window.history.back()}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.history.back()}
                className="text-gray-600 hover:text-gray-800"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Store className="text-white w-5 h-5" />
                </div>
                <h1 className="text-xl font-semibold text-gray-900">Clash Store</h1>
              </div>
            </div>
            
            {user && (
              <div className="flex items-center space-x-4">
                <img 
                  src={user.photoURL || ''} 
                  alt={user.displayName || 'User'} 
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm font-medium text-gray-700">
                  {user.displayName}
                </span>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-video rounded-xl overflow-hidden bg-gray-100">
              <img 
                src={product.bannerUrl} 
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </div>
            
            {product.extraImages.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {product.extraImages.map((imageUrl, index) => (
                  <div key={index} className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img 
                      src={imageUrl} 
                      alt={`${product.title} ${index + 1}`}
                      className="w-full h-full object-cover cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => window.open(imageUrl, '_blank')}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.title}</h1>
              <div className="flex items-center space-x-2 mb-4">
                <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <IndianRupee className="w-3 h-3 mr-1" />
                  ₹{product.price}
                </Badge>
              </div>
              <p className="text-gray-600 leading-relaxed">{product.description}</p>
            </div>

            {/* Purchase Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {approvedPurchase ? 'Access Product' : 'Purchase Product'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {approvedPurchase ? (
                  /* Access granted */
                  <div className="text-center space-y-4">
                    <div className="flex items-center justify-center space-x-2 text-green-600">
                      <CheckCircle className="w-6 h-6" />
                      <span className="font-medium">Purchase Approved!</span>
                    </div>
                    <p className="text-gray-600 text-sm">
                      Your purchase has been approved. You can now download the product.
                    </p>
                    {product.fileUrl && (
                      <Button
                        onClick={handleDownload}
                        className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download Product
                      </Button>
                    )}
                  </div>
                ) : showPurchaseForm ? (
                  /* Purchase form */
                  <form onSubmit={handlePurchase} className="space-y-4">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                      <h4 className="font-medium text-blue-900 mb-2">Payment Instructions</h4>
                      <p className="text-sm text-blue-700 mb-2">
                        Send ₹{product.price} to:
                      </p>
                      {product.upiId && (
                        <div className="text-sm text-blue-700 mb-2">
                          <strong>UPI ID:</strong> {product.upiId}
                        </div>
                      )}
                      {product.upiQrUrl && (
                        <div className="mt-2">
                          <img 
                            src={product.upiQrUrl} 
                            alt="UPI QR Code"
                            className="w-32 h-32 border border-blue-200 rounded-lg"
                          />
                        </div>
                      )}
                      <p className="text-xs text-blue-600 mt-2">
                        Upload payment screenshot below after completing payment
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="name">Your Name</Label>
                      <Input
                        id="name"
                        value={buyerName}
                        onChange={(e) => setBuyerName(e.target.value)}
                        placeholder="Enter your full name"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={buyerEmail}
                        onChange={(e) => setBuyerEmail(e.target.value)}
                        placeholder="Enter your email"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="screenshot">Payment Screenshot *</Label>
                      <Input
                        id="screenshot"
                        type="file"
                        accept="image/*"
                        onChange={(e) => setScreenshotFile(e.target.files?.[0] || null)}
                        required
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Upload a clear screenshot of your payment confirmation
                      </p>
                    </div>

                    <div className="flex space-x-3">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowPurchaseForm(false)}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={purchasing}
                        className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                      >
                        {purchasing ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Submitting...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4 mr-2" />
                            Submit Purchase
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                ) : (
                  /* Buy now button */
                  <div className="text-center space-y-4">
                    <div className="text-2xl font-bold text-gray-900">
                      ₹{product.price}
                    </div>
                    <Button
                      onClick={() => setShowPurchaseForm(true)}
                      className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg py-3"
                    >
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Buy Now
                    </Button>
                    <p className="text-xs text-gray-500">
                      Secure UPI payment • Instant approval • Digital delivery
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Product Details */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Product Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Price:</span>
                  <span className="font-medium">₹{product.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Payment:</span>
                  <span className="font-medium">UPI Only</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Delivery:</span>
                  <span className="font-medium">Digital Download</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Access:</span>
                  <span className="font-medium">After Admin Approval</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}